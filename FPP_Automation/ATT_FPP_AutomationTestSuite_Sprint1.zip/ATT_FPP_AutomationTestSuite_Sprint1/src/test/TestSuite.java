/**
 * This is the main test class. All the tests are defined here. 
 *
 * @author  FPP QE Team, PwC 
 * @version 1.0
 * @since   2017-05-08 
 */

package test;

import java.io.FileNotFoundException;
import java.io.IOException;

import jxl.read.biff.BiffException;

import org.openqa.selenium.Alert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testng.AUTBaseTest;
import client.FPPObjectRepository;
import client.FPPPricingManagerInboxPage;

public class TestSuite extends AUTBaseTest implements FPPObjectRepository {

	Alert alertWindow = null;
	FPPPricingManagerInboxPage objFPPPricingManagerInboxPage = new FPPPricingManagerInboxPage();

	@BeforeTest
	@Parameters({ "URL", "browser" })
	public void launchApplication(String URL, String browser) throws FileNotFoundException, IOException, InterruptedException {

		/* Description : Configuring the listeners for execution report */
		ReportsConfig();

		/* Opening browser */	
		setupBrowserAbsDriverPath(browser);
		Thread.sleep(5000);

		/* Launch FPP Application */
		homePageHandleAlert(URL,PricingManagerInbox.lblCompletedDeals,"xpath");
		/*Thread.sleep(2000);
		if (ExpectedConditions.alertIsPresent() != null)
		{
			alertWindow = driver.switchTo().alert();
			alertWindow.accept();
		}*/
	}

	@Test
	public void VerifyPricingManagerInbox() throws BiffException, IOException, InterruptedException {

		Thread.sleep(2000);
		/* verifying FPP Pricing Manager Inbox Page */
		objFPPPricingManagerInboxPage.verifyPricingManagerPortalPage();
		/* verifying Completed Deals Module in FPP Pricing Manager Inbox Page */
		objFPPPricingManagerInboxPage.verifyCompletedDealsModule();
		/* verifying My Inbox Module in FPP Pricing Manager Inbox Page */
		objFPPPricingManagerInboxPage.verifyMyInboxModule();
		/* verifying Deal Alerts Module in FPP Pricing Manager Inbox Page */
		//objFPPPricingManagerInboxPage.verifyDealAlertsModule();	

	}

	@AfterTest
	public void afterTest() throws Exception {

		/* Closing Browser */	
		killBrowser();
	}

}
