/**
 * This Class is a repository for all the required web elements. 
 *
 * @author  FPP QE Team, PwC 
 * @version 1.0
 * @since   2017-05-08 
 */

package client;

public interface FPPObjectRepository {

	public interface PricingManagerInbox {
		/*Description: web element locator for Completed Deals Field */
		//String lblCompletedDeals = "//*[@id='back-to-top']/div/div[1]/div/div/div[1]/div/div/h4";
		String lblCompletedDeals = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[1]/div/div/h4";
		/*Description: web element locator for Cycle Time Field */
		String lblCycleTime = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[1]/div/div/p-selectbutton/div/div[1]/span";
		/*Description: web element locator for Type Field */
		String lblType = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[1]/div/div/p-selectbutton/div/div[2]/span";

		/*Description: web element locator for Deal Alerts Field */
		String lblDealAlerts = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[2]/div/div/h4";

		/*Description: web element locator for My Inbox Field */
		String lblMyInbox = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[3]/div/div/h4";

		/*Description: web element locator for My Dashboard Field */
		String lblMyDashboard = "/html/body/app-root/div/app-inbox/div/div/h2";
		//*[@id="back-to-top"]/div/h2/text()
		/*Description: web element locator for Date Field */
		String lblDate = "/html/body/app-root/div/app-inbox/div/div/h2/span[2]";
		
		String lblDealInbox = "/html/body/app-root/div/app-inbox/div/div/div[2]/ul/li[1]";
		String lblTotDealCount = "/html/body/app-root/div/app-inbox/div/div/div[2]/ul/li[2]/div";
		String lblCurrMonth = "g.highcharts-xaxis-labels > text:nth-child(4) > tspan:nth-child(1)";
		String lbllastMonth = "g.highcharts-xaxis-labels > text:nth-child(3) > tspan:nth-child(1)";
		String lbl2ndlastMonth = "g.highcharts-xaxis-labels > text:nth-child(2) > tspan:nth-child(1)";
		String lbl3rdlastMonth = "g.highcharts-xaxis-labels > text:nth-child(1) > tspan:nth-child(1)";
		

		String lblCompletedDealsType1 = "g.highcharts-legend-item:nth-child(1) > text:nth-child(1)";
		String lblCompletedDealsType2 = "g.highcharts-legend-item:nth-child(2) > text:nth-child(1)";
		String lblCompletedDealsType3 = "g.highcharts-legend-item:nth-child(3) > text:nth-child(1)";
		String lblCompletedDealsType4 = "g.highcharts-legend-item:nth-child(4) > text:nth-child(1)";
		

		String lblMyInboxDealStatus1 = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[3]/div/div/div/div[2]/div[1]/div[2]";
		String lblMyInboxDealStatus2 = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[3]/div/div/div/div[2]/div[2]/div[2]";
		String lblMyInboxDealStatus3 = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[3]/div/div/div/div[2]/div[3]/div/div[2]";
		String lblMyInboxDealStatus4 = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[3]/div/div/div/div[3]/div[1]/div[2]";
		String lblMyInboxDealStatus5 = "/html/body/app-root/div/app-inbox/div/div/div[1]/div/div/div[3]/div/div/div/div[3]/div[2]/div[2]";
		
		/*Description: web element locator for Current Field */
		String lblCurrent = "/html/body/app-root/div/app-inbox/div/div/div[3]/div/div[1]/p-selectbutton/div/div[1]/span";
		String lblArchive = "/html/body/app-root/div/app-inbox/div/div/div[3]/div/div[1]/p-selectbutton/div/div[2]/span";
		
		String lblScoreInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[1]/span[2]";
		String lblCustomerInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[2]/span[2]";		
		String lblDealNameInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[3]/span[2]";	
		String lblDealVersionInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[4]/span[2]";	
		String lblProductsInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[5]/span[2]";	
		String lblDealNotesInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[6]/span[2]";		
		String lblMRCInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[7]/span[2]/p-dropdown/div/div[1]/select/option[1]";	
		String lblNRCInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[7]/span[2]/p-dropdown/div/div[1]/select/option[2]";	
		String lblTCVInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[8]/span[2]/p-dropdown/div/div[1]/select/option[1]";	
		String lblEBITInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[8]/span[2]/p-dropdown/div/div[1]/select/option[2]";	
		String lblApprovalLevelInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[9]/span[2]";	
		String lblDateCreatedInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[10]/span[2]/p-dropdown/div/div[1]/select/option[1]";	
		String lblDueDateInboxHeader = "/html/body/app-root/div/app-inbox/div/div/div[4]/div/p-datatable/div/div[1]/table/thead/tr/th[10]/span[2]/p-dropdown/div/div[1]/select/option[2]";	
		
	}
}


